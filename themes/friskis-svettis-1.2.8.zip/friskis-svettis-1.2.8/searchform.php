<form role="search" method="get" class="searchformWidget" action="<?php echo home_url( '/' ); ?>">
    <div>
        <input type="text" value="" name="s" class="searchWidget" />
        <input type="submit" class="searchsubmit" value="" />
    </div>
</form>